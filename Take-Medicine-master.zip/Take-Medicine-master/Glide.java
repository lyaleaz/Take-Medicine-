package my.takeMedDesign.app.phMedPanel;

import android.provider.Settings;

public class Glide {
    public static Settings.Global with(UpdateDelete_Med updateDelete_med) {

        return null;
    }

    public Glide load(String imageURL) {

        return  null;


    }
}
