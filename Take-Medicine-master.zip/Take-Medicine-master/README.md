# Take-Medicine

READ_ME:
כניסה למערכת כאדמן שהוא גם רוקח דרך הפרטים :

areen@gmail.com Email:
Pass:123456789
